Comandos.

dotnet new mvc


